// Put your own Twitter App keys here. See README.md for more detail.
module.exports = {
  consumer_key:         '18jShAUMRPDt3JcX4svUnaTgt',
  consumer_secret:      'pwTAnq0fH9YAwpGkgnSQDGpEQu6D8JYo4sPQcLNsIK5Wz2Fzyu',
  access_token:         '929416071299436544-CSsylPfkCCDk62t0DBAwa4cDU2gNi6i',
  access_token_secret:  'xoUdUeJnZ8hzghDJyV2RY6Ot13Vc1S6xkAtgbznIhEHPX'
}
